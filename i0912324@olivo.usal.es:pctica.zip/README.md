# Embedded SQL exercise

Use:

```
$ ./target/app question -a "Example question"
1
$ ./target/app answer -a 1 "Dummy answer"
$ ./target/app answer -a 1 "Real answer" --correct
$ ./target/app question -s 1
