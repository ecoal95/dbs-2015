#ifndef ANSWER_H_
#define ANSWER_H_
int answer(int argc, char** argv);
#endif
