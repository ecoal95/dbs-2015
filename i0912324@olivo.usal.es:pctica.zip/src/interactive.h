#ifndef INTERACTIVE_H_
#define INTERACTIVE_H_

int interactive(int argc, char** argv);

#endif
