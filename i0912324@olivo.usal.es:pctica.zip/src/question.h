#ifndef QUESTION_H_
#define QUESTION_H_

int question(int argc, char** argv);

#endif
