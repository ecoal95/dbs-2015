#ifndef EXAM_H_
#define EXAM_H_

int exam(int argc, char** argv);

#endif
