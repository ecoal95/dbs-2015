#ifndef QUESTION_H_
#define QUESTION_H_

int question(int argc, char** argv);
int show_exams_for_question(int id);
int show_question(int argc, char** argv);

#endif
